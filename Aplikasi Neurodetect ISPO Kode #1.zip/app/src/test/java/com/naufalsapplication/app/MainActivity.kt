package com.naufalsapplication.app

import com.naufalsapplication.app.appcomponents.base.BaseActivity
import com.naufalsapplication.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}